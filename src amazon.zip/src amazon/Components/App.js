import React from 'react';
import { Route } from 'react-router-dom';
import Navbar from './Navbar';
import Home from '../Components/Home';
import Login from '../Components/Login';
import Register from '../Components/Register';
import Cart from '../Components/Cart';
function App( props ) {
    return (
        <div>
            <Navbar />
            <div className="container my-4">
            <Route path="/" exact component={Home}/>
            <Route path="/login" exact component={Login}/>
            <Route path="/login/register" exact component={Register}/>
            <Route path="/login/cart" exact component={Cart} />
            </div>
            </div>
            );
            }
    
    export default App;