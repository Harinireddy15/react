import React from 'react';

function Login(props) {
    return (
        <div>
            <h2>Login Page</h2>
                <hr />
                <div class="form-group">
                        {/* <label for="text">Username</label>
                        <input type="text" name="username" id="title" class="form-control "/>
                        <small id="usernameHelp" class="text-muted">
                            Please enter your username
                        </small> */}
                         <div className="firstName">
                            <label htmlFor="userName">Username:</label>
                            <input  className="userName" placeholder="userName" type="text" 
                            name="userName" />
                           </div>
                           <small id="usernameHelp" class="text-muted">
                            Please enter your username
                        </small>

                        </div>
                        <br/>
                        <div class="form-group">
                        <div className="firstName">
                        <label htmlFor="password">password:</label>
                            <input  className="password" placeholder="password" type="password" 
                            name="password" />
                            </div>
                           <small id="passwordHelp" class="text-muted">
                            Please enter your username
                        </small>
                       
                        </div>
                     
                        {/* <a button className="btn btn-primary btn-sm btn-space" role="button">Login</a> */}
                        <a button className="btn btn-primary btn-sm btn-space" href="/login/register" role="button">Register</a>
                        {/* <a button className="btn btn-primary btn-sm btn-space" role="button">Register</a> */}
                        {/* <a button className="btn btn-primary btn-sm btn-space" role="button">Cart</a> */}
                        <a button className="btn btn-primary btn-sm btn-space" href="/login/cart" role="button">Login</a>
                        </div>
                   
    )}
        
export default Login;
