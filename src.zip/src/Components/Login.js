import React from 'react';

function Login(props) {
    return (
        <div>
            <h2>Login Page</h2>
                <hr />
                <div class="form-group">
                        <label for="text">Username</label>
                        <input type="text" name="username" id="title" class="form-control "/>
                        <small id="usernameHelp" class="text-muted">
                            Please enter your username
                        </small>
                        </div>
                        <br/>
                        <div class="form-group">
                        <label for="text">Password</label>
                        <input type="text" name="password" id="title" class="form-control "/>
                        <small id="passwordHelp" class="text-muted">
                            Please enter your password
                        </small>
                        </div>
                        <a button className="btn btn-primary btn-sm btn-space" role="button">Login</a>
                        <a button className="btn btn-primary btn-sm btn-space" role="button">Register</a>

                    </div>
                    );
        
}
export default Login;